package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

public class cart {
	
	WebDriver driver = null;

	
	@Given("I am logged in")
	public void i_am_logged_in() {
		System.setProperty("webdriver.chrome.driver", "C:\\Eclipse WorkSpace\\AmazonAutomationAssign\\src\\test\\resources\\driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.navigate().to("https://www.amazon.in/"); 
		
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		
		driver.navigate().to("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2F%3Fref_%3Dnav_ya_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&");
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div[1]/form/div/div/div/div[1]/input[1]")).sendKeys("shubhamp22301@gmail.com");
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div[1]/form/div/div/div/div[2]/span/span/input")).click();
		
		driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS) ;
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div/form/div/div[1]/input")).sendKeys("Shubham@22");
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div/form/div/div[2]/span/span/input")).click();
	
		
	}

	@When("I click on cart")
	public void i_click_on_cart() {
	    // Write code here that turns the phrase above into concrete actions
		driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS) ;

	    driver.findElement(By.xpath("/html/body/div[1]/header/div/div[1]/div[3]/div/a[5]/div[1]/span[1]")).click();

	}

	@Then("cart page opens")
	public void cart_page_opens() {
	    // Write code here that turns the phrase above into concrete actions
		String Title = "Amazon.in Shopping Cart";
		String PageTitle = driver.getTitle();
		
		Assert.assertEquals(Title, PageTitle);
		driver.close();
		/*
		if(Title.equals(PageTitle)) {
			System.out.println("You are on Cart Page.....");
		}
		else {
			System.out.println("You are not on Cart Page......");

		}
		*/
	}

}
