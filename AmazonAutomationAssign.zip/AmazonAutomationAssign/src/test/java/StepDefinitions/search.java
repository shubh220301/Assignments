package StepDefinitions;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;


public class search {
	
	WebDriver driver = null;

	@Given("I am logged in2")
	public void i_am_logged_in2() {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Eclipse WorkSpace\\AmazonAutomationAssign\\src\\test\\resources\\driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.navigate().to("https://www.amazon.in/"); 
		
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
		
		driver.navigate().to("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2F%3Fref_%3Dnav_ya_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&");
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div[1]/form/div/div/div/div[1]/input[1]")).sendKeys("shubhamp22301@gmail.com");
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div[1]/form/div/div/div/div[2]/span/span/input")).click();
		
		driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div/form/div/div[1]/input")).sendKeys("Shubham@22");
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div/form/div/div[2]/span/span/input")).click();
	
	}

	@When("I search something")
	public void i_search_something() {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("/html/body/div[1]/header/div/div[1]/div[2]/div/form/div[2]/div[1]/input")).sendKeys("earbuds");
		driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div[1]/header/div/div[1]/div[2]/div/form/div[3]/div/span/input")).click();

	}

	@Then("I am directed to respective page")
	public void i_am_directed_to_respective_page() {
	    // Write code here that turns the phrase above into concrete actions
		String Url = "https://www.amazon.in/s?k=earbuds&ref=nb_sb_noss";
		String CurrentUrl = driver.getCurrentUrl();
		
		Assert.assertEquals(Url, CurrentUrl);
		driver.close();
//		if(Url.equals(CurrentUrl)) {
//			System.out.println("You are on Searched Page.....");
//		}
//		else {
//			System.out.println("You are not on Searched Page......");
//
//		}
	}
	/*
	@And("I add product to cart")
	public void i_add_product_to_cart() {
	    // Write code here that turns the phrase above into concrete actions
		//driver.navigate().to("https://www.amazon.in/Airdopes-141-Playtime-Resistance-Bluetooth/dp/B09N3ZNHTY/ref=sr_1_1_sspa?keywords=earbuds&qid=1672911838&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1");
		//driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[1]/div[1]/div/span[1]/div[1]/div[3]/div/div/div/div/div/div/div/div[2]/div/div/div[1]/h2/a/span")).click();
		String oldTab = driver.getWindowHandle();
		driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[1]/div/span[1]/div[1]/div[3]/div/div/div/div/div/div/div/div[2]/div/div/div[1]/h2/a/span")).click();
		ArrayList<String> newTab = new ArrayList<String>(driver.getWindowHandles());
		driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
		 driver.switchTo().window(newTab.get(1));
		
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button\"]")).click();
		
	}
	*/

}
